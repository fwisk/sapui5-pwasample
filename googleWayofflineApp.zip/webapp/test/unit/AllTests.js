sap.ui.define([
	"offlineApp/offlineApp/test/unit/controller/View1.controller"
], function () {
	"use strict";
});